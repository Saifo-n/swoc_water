import React, { useState, useEffect } from "react";
import Link from "next/link";
import { useTheme } from "../contexts/ThemeContext";
import { useLanguage } from "@/contexts/LanguageContext";
import { useFontSize } from "@/contexts/FontSizeContext";

const Strategic = () => {
    const { isDarkMode } = useTheme();
    const { language } = useLanguage();
    const { fontSize } = useFontSize();

    const [currentPage, setCurrentPage] = useState<string>("");

    useEffect(() => {
        if (typeof window !== "undefined") {
            const savedUrl = sessionStorage.getItem("currentUrl");
            const currentPath = typeof window !== "undefined" && window.location ? window.location.pathname : "";
            if (savedUrl && currentPath !== savedUrl) {
                window.history.pushState(null, "", savedUrl);
                setCurrentPage(savedUrl);
            } else {
                setCurrentPage(currentPath);
            }
        }
    }, []);

    const handleNavigation = (url: string) => {
        if (typeof window !== "undefined" && window.location.pathname !== url) {
            window.history.pushState(null, "", url);
            sessionStorage.setItem("currentUrl", url);
            setCurrentPage(url);
        }
    };

    return (
        <div className={isDarkMode ? "bg-gray-900/90 text-white" : "bg-white text-black"}>
            <div
                className="relative h-[250px] bg-cover bg-center rounded-lg"
                style={{ backgroundImage: "url('https://blog.carro.co/wp-content/uploads/2022/05/10-Dam-In-Thailand-4.jpg')" }}>
                <div className="absolute inset-0 bg-black/50 flex flex-col justify-center items-center text-white text-center">
                    <h1
                        className="text-4xl font-bold mb-4"
                        style={{ fontSize: `calc(1rem + ${fontSize}px)` }}>
                        {language === "ไทย" ? "ยุทธศาสตร์" : "Strategy"}
                    </h1>
                </div>
            </div>

            <div className="text-left mt-1 px-6 py-8">
                <div className="mb-1">
                    <nav className="text-lg">
                        <Link
                            href="/division"
                            className="text-blue-500 font-bold hover:underline"
                            onClick={() => handleNavigation("/division")}>
                            {language === "ไทย" ? "หน้าแรก" : "Home"}
                        </Link>
                        <span className="mx-2">/</span>
                        <span className="font-semibold">
                            {language === "ไทย" ? "เกี่ยวกับเรา" : "About Us"}
                        </span>
                        <span className="mx-2">/</span>
                        <span>{language === "ไทย" ? "ยุทธศาสตร์" : "Strategy"}</span>
                    </nav>
                </div>

                <div className="p-6 space-y-6">
                    {/* Content for the strategic section */}
                    <div className="flex justify-center space-x-8 flex-wrap">
                        {/* Add your content and strategy related components here */}
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Strategic;
