import React, { useState, useEffect } from "react";
import { useTheme } from "../contexts/ThemeContext";
import { useLanguage } from "@/contexts/LanguageContext";
import { useFontSize } from "@/contexts/FontSizeContext";

const Structure = () => {
  const { isDarkMode } = useTheme();
  const { language } = useLanguage();
  const { fontSize } = useFontSize();

  // Fix for the error, avoid using null.pathname
  const [currentPage, setCurrentPage] = useState<string>(typeof window !== "undefined" && window.location ? window.location.pathname : "");

  useEffect(() => {
    if (typeof window !== "undefined") {
      const savedUrl = sessionStorage.getItem("currentUrl");
      const currentPath = window.location.pathname;
      if (savedUrl && currentPath !== savedUrl) {
        window.history.pushState(null, "", savedUrl);
        setCurrentPage(savedUrl);
      }
    }
  }, [setCurrentPage]);

  const handleNavigation = (url: string) => {
    if (typeof window !== "undefined" && window.location.pathname !== url) {
      window.history.pushState(null, "", url);
      sessionStorage.setItem("currentUrl", url);
      setCurrentPage(url);
    }
  };

  return (
    <div className={isDarkMode ? "bg-gray-900/90 text-white" : "bg-white text-black"}>
      <div className="relative h-[250px] bg-cover bg-center rounded-lg" style={{ backgroundImage: "url('https://blog.carro.co/wp-content/uploads/2022/05/10-Dam-In-Thailand-4.jpg')" }}>
        <div className="absolute inset-0 bg-black/50 flex flex-col justify-center items-center text-white text-center">
          <h1 className="text-4xl font-bold mb-4" style={{ fontSize: `calc(1rem + ${fontSize}px)` }}>
            {language === "ไทย" ? "โครงสร้างหน่วยงาน" : "Organizational Structure"}
          </h1>
        </div>
      </div>

      <div className="text-left mt-1 px-6 py-8">
        <div className="mb-1">
          <nav className="text-lg">
            <span
              className="text-blue-500 font-bold hover:underline"
              onClick={() => handleNavigation("/division")}
            >
              {language === "ไทย" ? "หน้าแรก" : "Home"}
            </span>
            <span className="mx-2">/</span>
            <span className="font-semibold">{language === "ไทย" ? "เกี่ยวกับเรา" : "About Us"}</span>
            <span className="mx-2">/</span>
            <span>{language === "ไทย" ? "โครงสร้างหน่วยงาน" : "Organizational Structure"}</span>
          </nav>
        </div>

        {/* Add more content below as needed */}
      </div>
    </div>
  );
};

export default Structure;
