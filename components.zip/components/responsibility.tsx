import React, { useState, useEffect } from "react";
import Link from "next/link";
import { useTheme } from "../contexts/ThemeContext";
import { useLanguage } from "@/contexts/LanguageContext";
import { useFontSize } from "@/contexts/FontSizeContext";

const Responsibility = () => {
    const { isDarkMode } = useTheme();
    const { language } = useLanguage();
    const { fontSize } = useFontSize();

    const [selectedSection, setSelectedSection] = useState("general");
    const [currentPage, setCurrentPage] = useState<string>("");

    useEffect(() => {
        if (typeof window !== "undefined") {
            const savedUrl = sessionStorage.getItem("currentUrl");
            if (savedUrl && window.location.pathname !== savedUrl) {
                window.history.pushState(null, "", savedUrl);
                setCurrentPage(savedUrl);
            } else {
                setCurrentPage(window.location.pathname);
            }
        }
    }, []);

    const handleNavigation = (url: string) => {
        if (typeof window !== "undefined" && window.location.pathname !== url) {
            window.history.pushState(null, "", url);
            sessionStorage.setItem("currentUrl", url);
            setCurrentPage(url);
        }
    };

    const handleSectionChange = (section: string) => {
        setSelectedSection(section);
    };

    return (
        <div className={isDarkMode ? "bg-gray-900/90 text-white" : "bg-white text-black"}>
            <div
                className="relative h-[250px] bg-cover bg-center rounded-lg"
                style={{ backgroundImage: "url('https://blog.carro.co/wp-content/uploads/2022/05/10-Dam-In-Thailand-4.jpg')" }}>
                <div className="absolute inset-0 bg-black/50 flex flex-col justify-center items-center text-white text-center">
                    <h1
                        className="text-4xl font-bold mb-4"
                        style={{ fontSize: `calc(1rem + ${fontSize}px)` }}>
                        {language === "ไทย" ? "หน้าที่ความรับผิดชอบ" : "Responsibilities"}
                    </h1>
                </div>
            </div>

            <div className="text-left mt-1 px-6 py-8">
                <div className="mb-1">
                    <nav className="text-lg">
                        <Link
                            href="/division"
                            className="text-blue-500 font-bold hover:underline"
                            onClick={() => handleNavigation("/division")}>
                            {language === "ไทย" ? "หน้าแรก" : "Home"}
                        </Link>
                        <span className="mx-2">/</span>
                        <span className="font-semibold">
                            {language === "ไทย" ? "เกี่ยวกับเรา" : "About Us"}
                        </span>
                        <span className="mx-2">/</span>
                        <span>{language === "ไทย" ? "หน้าที่ความรับผิดชอบ" : "Responsibilities"}</span>
                    </nav>
                </div>

                <div className="p-6 space-y-6">
                    <p
                        className={`mb-4 text-lg text-center font-bold ${isDarkMode ? "text-white" : "text-black"}`}
                        style={{
                            fontSize: `calc(0.2rem + ${fontSize}px)`,
                            whiteSpace: 'normal',
                            wordBreak: 'break-word',
                        }}>
                        {language === "ไทย"
                            ? "ส่วนประมวลวิเคราะห์สถานการณ์น้ำ แบ่งออกเป็น 2 ฝ่าย ดังนี้"
                            : "The Water Situation Analysis Section is divided into two units as follows."}
                    </p>

                    <div className="flex justify-center space-x-8 flex-wrap">
                        <button
                            onClick={() => handleSectionChange("general")}
                            className={`button ${selectedSection === "general"
                                ? "bg-blue-500 text-white shadow-lg transform scale-105"
                                : "bg-gray-200 text-black hover:bg-blue-100 hover:scale-105"
                                }`}>
                            {language === "ไทย" ? "ส่วนประมวลวิเคราะห์สถานการณ์น้ำ" : "Water Situation Analysis Section"}
                        </button>
                        <button
                            onClick={() => handleSectionChange("forecast")}
                            className={`button ${selectedSection === "forecast"
                                ? "bg-blue-500 text-white shadow-lg transform scale-105"
                                : "bg-gray-200 text-black hover:bg-blue-100 hover:scale-105"
                                }`}>
                            {language === "ไทย" ? "ฝ่ายติดตามและพยากรณ์สถานการณ์น้ำ" : "Water Situation Monitoring and Forecasting Unit"}
                        </button>
                        <button
                            onClick={() => handleSectionChange("analysis")}
                            className={`button ${selectedSection === "analysis"
                                ? "bg-blue-500 text-white shadow-lg transform scale-105"
                                : "bg-gray-200 text-black hover:bg-blue-100 hover:scale-105"
                                }`}>
                            {language === "ไทย" ? "ฝ่ายประมวลและวิเคราะห์สถานการณ์น้ำ" : "Water Situation Analysis and Evaluation Unit"}
                        </button>
                    </div>

                    <div className="flex justify-center items-center mt-6 space-y-4">
                        {/* Content for each selected section goes here */}
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Responsibility;
